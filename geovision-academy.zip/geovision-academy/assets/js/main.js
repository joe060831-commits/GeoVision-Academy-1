/* GeoVision Academy — shared site behavior */

document.addEventListener('DOMContentLoaded', () => {

  /* ---- footer year ---- */
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());

  /* ---- mobile nav toggle ---- */
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));
  }

  /* ---- scroll reveal ---- */
  const revealEls = document.querySelectorAll('[data-reveal]');
  if ('IntersectionObserver' in window && revealEls.length) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => obs.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-visible'));
  }

  /* ---- course filter chips (Courses page) ---- */
  const chips = document.querySelectorAll('[data-filter]');
  const courseCards = document.querySelectorAll('[data-status]');
  if (chips.length && courseCards.length) {
    chips.forEach(chip => {
      chip.addEventListener('click', () => {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const filter = chip.getAttribute('data-filter');
        courseCards.forEach(card => {
          const show = filter === 'all' || card.getAttribute('data-status') === filter;
          card.style.display = show ? '' : 'none';
        });
      });
    });
  }

  /* ---- waitlist form(s) ---- */
  document.querySelectorAll('[data-waitlist-form]').forEach(form => {
    const success = form.parentElement.querySelector('[data-waitlist-success]');
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      form.classList.add('hidden');
      if (success) success.classList.remove('hidden');
    });
  });

  /* ---- certificate verification (Verify page) ---- */
  const verifyForm = document.querySelector('[data-verify-form]');
  if (verifyForm) {
    const input = verifyForm.querySelector('input[name="cert-id"]');
    const validBox = document.querySelector('[data-result-valid]');
    const invalidBox = document.querySelector('[data-result-invalid]');
    const certPreview = document.querySelector('[data-cert-preview]');
    const downloadBtn = document.querySelector('[data-cert-download]');
    const idOut = document.querySelector('[data-cert-id-out]');

    const SAMPLE_RECORDS = {
      'GVA-GIS-0001': { name: 'John Doe', course: 'Introduction to GIS', issued: 'May 2026' }
    };

    verifyForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const id = (input.value || '').trim().toUpperCase();
      validBox.classList.add('hidden');
      invalidBox.classList.add('hidden');
      certPreview.classList.add('hidden');
      if (downloadBtn) downloadBtn.classList.add('hidden');

      const record = SAMPLE_RECORDS[id];
      if (record) {
        validBox.classList.remove('hidden');
        certPreview.classList.remove('hidden');
        if (downloadBtn) downloadBtn.classList.remove('hidden');
        if (idOut) idOut.textContent = id;
        document.querySelectorAll('[data-cert-name-out]').forEach(el => el.textContent = record.name);
        document.querySelectorAll('[data-cert-course-out]').forEach(el => el.textContent = record.course);
        document.querySelectorAll('[data-cert-issued-out]').forEach(el => el.textContent = record.issued);
      } else {
        invalidBox.classList.remove('hidden');
      }
    });
  }

  /* ---- certificate "download" affordance: print just the certificate card ---- */
  document.querySelectorAll('[data-cert-download]').forEach(btn => {
    btn.addEventListener('click', () => window.print());
  });

});
